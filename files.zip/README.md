# Site AN'SAROUD DINE BAMBILOR

Site vitrine statique (HTML5 / CSS3 / JS vanilla), prêt pour GitHub Pages.

## Structure
```
index.html          Accueil
a-propos.html        À propos
activites.html       Nos activités
projets.html         Nos projets
actualites.html      Actualités
galerie.html         Galerie photos et vidéos
equipe.html          Équipe dirigeante
don.html             Faire un don
adhesion.html        Adhésion
contact.html         Contact
css/style.css        Feuille de style unique (couleurs, typographie, composants)
js/main.js           Interactions (menu, compteurs, galerie, FAQ, formulaires, carrousel)
images/              Vos photos (voir ci-dessous)
robots.txt, sitemap.xml   Fichiers SEO
```

## Ajouter vos vraies photos
Chaque `<img>` pointe vers un fichier dans `images/` (ex. `images/communaute.jpg`,
`images/galerie-1.jpg`, `images/president.jpg`...). Tant qu'une image n'existe pas,
un motif doré de remplacement s'affiche automatiquement (aucune erreur visible).
Déposez vos fichiers avec les mêmes noms dans `images/` pour qu'ils apparaissent.

## Personnaliser le texte
Tout le texte est directement dans les fichiers `.html` — remplacez les noms des
membres du bureau, les chiffres clés, les projets et les actualités par vos
propres informations.

## Formulaires
Les formulaires (contact, don, adhésion, newsletter) affichent une confirmation
côté client mais n'envoient pas encore d'email. Pour les rendre fonctionnels,
reliez-les à un service comme Formspree, EmailJS ou Google Forms (ajoutez
simplement l'action du formulaire dans le HTML).

## Carte Google Maps
La carte sur `contact.html` utilise une recherche générique « Bambilor, Sénégal ».
Remplacez l'URL de l'`<iframe>` par l'adresse exacte de votre siège via
Google Maps → Partager → Intégrer une carte, pour plus de précision.

## Déploiement sur GitHub Pages
1. Créez un dépôt GitHub et poussez tous ces fichiers à la racine.
2. Dans les paramètres du dépôt → Pages, choisissez la branche `main` et le
   dossier `/ (root)`.
3. Votre site sera disponible à `https://votre-compte.github.io/nom-du-depot/`.
4. Pensez à mettre à jour les URLs `https://ansarouddine-bambilor.sn/` dans
   `sitemap.xml`, `robots.txt` et les balises `<meta>` de chaque page avec votre
   propre nom de domaine une fois configuré.

## Réseaux sociaux
Remplacez les liens `https://facebook.com`, `https://instagram.com` et
`https://youtube.com` (en-tête et pied de page) par les vraies pages de
l'association.
